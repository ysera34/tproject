package com.tacademy.v04.chemi.view.activity;

/**
 * Created by yoon on 2016. 11. 14..
 */

public class SplashActivity extends AppBaseActivity {
}
