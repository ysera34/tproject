package com.tacademy.v04.chemi.view.activity.product;

import com.tacademy.v04.chemi.view.activity.AppBaseActivity;

/**
 * Created by yoon on 2016. 11. 14..
 */

public class ProductActivity extends AppBaseActivity {
}
