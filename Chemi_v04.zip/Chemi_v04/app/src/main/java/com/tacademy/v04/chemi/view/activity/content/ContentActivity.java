package com.tacademy.v04.chemi.view.activity.content;

import com.tacademy.v04.chemi.view.activity.AppBaseActivity;

/**
 * Created by yoon on 2016. 11. 14..
 */

public class ContentActivity extends AppBaseActivity {
}
