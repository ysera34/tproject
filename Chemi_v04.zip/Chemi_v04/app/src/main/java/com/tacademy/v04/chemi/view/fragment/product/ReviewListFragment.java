package com.tacademy.v04.chemi.view.fragment.product;

import android.support.v4.app.Fragment;

/**
 * Created by yoon on 2016. 11. 14..
 */

public class ReviewListFragment extends Fragment {
}
