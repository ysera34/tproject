package com.tacademy.v04.chemi.view.fragment.navigation;

import android.support.v4.app.Fragment;

/**
 * Created by yoon on 2016. 11. 14..
 * ChildFragment of ArchiveFragment
 */

public class ArchiveProductFragment extends Fragment {
}
