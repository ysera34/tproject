package com.tacademy.v04.chemi.view.activity.product;

import android.os.Bundle;
import android.support.annotation.Nullable;

import com.tacademy.v04.chemi.R;
import com.tacademy.v04.chemi.view.activity.AppBaseActivity;

/**
 * Created by yoon on 2016. 11. 14..
 */

public class SearchActivity extends AppBaseActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
    }
}
