package com.tacademy.v04.chemi.view.fragment.product;

import android.support.v4.app.DialogFragment;

/**
 * Created by yoon on 2016. 11. 14..
 */

public class ChemicalDialogFragment extends DialogFragment {
}
