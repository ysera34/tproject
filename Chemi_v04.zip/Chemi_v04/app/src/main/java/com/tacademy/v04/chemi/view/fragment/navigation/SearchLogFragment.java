package com.tacademy.v04.chemi.view.fragment.navigation;

import android.support.v4.app.Fragment;

/**
 * Created by yoon on 2016. 11. 14..
 * flows from Navigation Drawer menu Button
 * Search Log Custom Search, latest Search Log
 */

public class SearchLogFragment extends Fragment {
}
